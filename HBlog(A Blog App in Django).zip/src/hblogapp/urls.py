from django.contrib import admin
from django.urls import path, include
from hblogapp.views.index import Index
from hblogapp.views.post import Post
from hblogapp.views.subscribe import Subscribe

urlpatterns = [
    path("", Index.as_view(), name="index"),
    path("article", Post.as_view(), name="post"),
    path("subscribe", Subscribe.as_view())
]
