from django.db import models


class Tags(models.Model):
    tag = models.CharField(max_length=15)

    def __str__(self):
        return self.tag