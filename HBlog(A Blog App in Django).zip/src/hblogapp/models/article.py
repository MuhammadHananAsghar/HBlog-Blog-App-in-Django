from django.db import models
from datetime import datetime
from .tags import Tags

class Article(models.Model):
    title = models.CharField(max_length=100, default='')
    description = models.CharField(max_length=500, default='')
    date = models.DateTimeField(default = datetime.now(),auto_now=False, auto_now_add=False)
    image = models.ImageField(upload_to='uploads/article',default='')
    tag = models.ForeignKey(Tags, on_delete=models.CASCADE)

    @staticmethod
    def get_all_articles():
        return Article.objects.all()
    
    @staticmethod
    def get_article_by_click(id):
        return Article.objects.filter(id = id)