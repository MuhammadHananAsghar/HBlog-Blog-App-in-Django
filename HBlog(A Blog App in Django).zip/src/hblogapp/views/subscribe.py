from django.views import View
from django.shortcuts import render, HttpResponse, redirect

class Subscribe(View):
    def get(self, request):
        return redirect("index")
    
    def post(self, request):
        return HttpResponse("You Have Successfully Subscribed.")