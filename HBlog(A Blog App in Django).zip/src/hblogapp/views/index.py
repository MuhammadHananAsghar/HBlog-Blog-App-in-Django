from django.views import View
from django.shortcuts import render
from hblogapp.models.article import Article


class Index(View):
    def get(self, request):
        articles = Article.get_all_articles()
        return render(request, "index.html",{"articles":articles})