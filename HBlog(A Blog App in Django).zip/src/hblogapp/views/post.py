from django.views import View
from django.shortcuts import render, redirect
from hblogapp.models.article import Article

class Post(View):
    def get(self, request):
        return redirect("index")
    
    def post(self, request):
        id = request.POST.get("artcle_id","")
        article = Article.get_article_by_click(id)[0]
        return render(request, "post.html", {"article":article})
