from django.contrib import admin
from .models.article import Article
from .models.tags import Tags

class AdminTags(admin.ModelAdmin):
    list_display = ['tag']

class AdminArticle(admin.ModelAdmin):
    list_display = ['title','date','tag']

# Register your models here.
admin.site.register(Article, AdminArticle)
admin.site.register(Tags, AdminTags)